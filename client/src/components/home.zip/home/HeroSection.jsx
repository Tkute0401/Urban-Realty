import { MagnifyingGlassIcon, StarIcon } from "@heroicons/react/24/outline";
import { useInView } from "framer-motion";
import { React,useRef } from "react";
import { motion } from 'framer-motion';

// 2. Hero Section with Search and Map
export const HeroSection = () => {
  const ref = useRef();
  const isInView = useInView(ref, { once: true, margin: '-20%' });

  return (
    <section ref={ref} className="pt-40 pb-32">
      <div className="max-w-7xl mx-auto px-8">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={isInView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.8 }}
          className="text-center mb-16"
        >
          <h1 className="font-playfair text-[59px] leading-[1.1] font-bold mb-8">
            Find Your
            <br />
            Perfect <span className="text-primary">Spot.</span>
          </h1>

          <motion.div
            initial={{ opacity: 0 }}
            animate={isInView ? { opacity: 1 } : {}}
            transition={{ delay: 0.3 }}
            className="relative max-w-2xl mx-auto"
          >
            <div className="absolute inset-0 bg-white/90 backdrop-blur-[6px] rounded-full" />
            <div className="relative flex items-center px-8 py-4">
              <input
                type="text"
                placeholder="Search properties..."
                className="w-full bg-transparent outline-none placeholder:text-gray-400"
              />
              <MagnifyingGlassIcon className="w-6 h-6 text-primary" />
            </div>
          </motion.div>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, scale: 0.95 }}
          animate={isInView ? { opacity: 1, scale: 1 } : {}}
          transition={{ delay: 0.5 }}
          className="relative h-[600px] bg-gray-100 rounded-[32px] overflow-hidden"
        >
          {/* Map implementation */}
          <div className="absolute inset-0 bg-gray-300" />

          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={isInView ? { opacity: 1, y: 0 } : {}}
            transition={{ delay: 0.8 }}
            className="absolute bottom-7 right-7 bg-white p-5 rounded-xl shadow-lg"
          >
            <div className="flex gap-1.5 mb-1">
              {[...Array(5)].map((_, i) => (
                <StarIcon key={i} className="w-5 h-5 text-yellow-400 fill-yellow-400" />
              ))}
            </div>
            <span className="text-sm font-lato font-semibold text-gray-600">FROM 6,900+ CUSTOMERS</span>
          </motion.div>
        </motion.div>
      </div>
    </section>
  );
};
export default HeroSection;