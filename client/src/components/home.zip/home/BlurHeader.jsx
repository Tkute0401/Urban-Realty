import React from 'react';
import { motion } from "framer-motion";
import { BuildingOfficeIcon, UserIcon } from "@heroicons/react/24/outline";

// 1. Blur Header Component
export const BlurHeader = () => {
  const navigation = ['City', 'Property', 'Services', 'Contact Us'];
  
  return (
    <motion.header
      initial={{ opacity: 0, y: -20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.8 }}
      className="fixed top-0 w-full h-20 bg-white/90 backdrop-blur-[6px] z-50"
    >
      <div className="max-w-7xl mx-auto px-8 h-full flex items-center justify-between">
        <div className="flex items-center gap-3">
          <BuildingOfficeIcon className="w-8 h-8 text-primary" />
          <span className="font-playfair text-2xl font-bold">UR 360</span>
        </div>

        <nav className="hidden lg:flex gap-10">
          {navigation.map((item) => (
            <a
              key={item}
              className="font-lato text-lg font-medium text-secondary hover:text-primary transition-colors duration-200"
            >
              {item}
            </a>
          ))}
        </nav>

        <button className="flex items-center gap-2 px-4 py-2.5 bg-primary/10 rounded-lg hover:bg-primary/20 transition-colors">
          <UserIcon className="w-5 h-5 text-primary" />
          <span className="font-lato font-semibold">ACCOUNT</span>
        </button>
      </div>
    </motion.header>
  );
};
export default BlurHeader;