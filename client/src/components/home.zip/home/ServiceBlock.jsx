import { ChevronRightIcon } from "@heroicons/react/24/outline";
import { useInView } from "react-intersection-observer";
import { motion } from "framer-motion";

export const ServiceBlock = ({ reverse }) => {
  const [ref, inView] = useInView({
    threshold: 0.1,
    triggerOnce: true,
  });

  return (
    <motion.section
      ref={ref}
      initial={{ opacity: 0, x: reverse ? 50 : -50 }}
      animate={inView ? { opacity: 1, x: 0 } : {}}
      transition={{ duration: 0.6 }}
      className="py-20"
    >
      <div className={`max-w-7xl mx-auto px-8 flex flex-col ${reverse ? 'lg:flex-row-reverse' : 'lg:flex-row'} gap-12`}>
        <div className="lg:w-1/2 h-[500px] bg-gray-200 rounded-2xl" />
        
        <div className="lg:w-1/2 flex flex-col justify-center">
          <div className="max-w-md">
            <span className="text-primary font-lato font-bold mb-4">EXCLUSIVE OFFERS</span>
            <h2 className="font-playfair text-[39px] font-bold mb-6">Premium Properties in Prime Locations</h2>
            <p className="font-lato text-gray-600 mb-8">
              Discover curated selections of luxury properties with verified ownership and complete documentation.
            </p>
            <button className="flex items-center gap-2 group">
              <span className="font-lato font-semibold">Explore Listings</span>
              <ChevronRightIcon className="w-5 h-5 transition-transform group-hover:translate-x-1" />
            </button>
          </div>
        </div>
      </div>

      <div className="my-20 border-t-2 border-gray-200 rotate-3 w-4/5 mx-auto" />
    </motion.section>
  );
};

export default ServiceBlock;