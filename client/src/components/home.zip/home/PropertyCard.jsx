// 3. Property Card Component
import { HeartIcon, HomeIcon, MapPinIcon, StarIcon } from '@heroicons/react/24/outline';
import { useInView } from 'react-intersection-observer';
import { motion } from 'framer-motion';

const PropertyCard = ({ index }) => {
  const [ref, inView] = useInView({
    threshold: 0.1,
    triggerOnce: true,
  });

  return (
    <motion.div
      ref={ref}
      initial={{ opacity: 0, y: 50 }}
      animate={inView ? { opacity: 1, y: 0 } : {}}
      transition={{ duration: 0.4, delay: index * 0.3 }}
      className="bg-white rounded-2xl overflow-hidden shadow-lg"
    >
      <div className="relative aspect-square">
        <div className="bg-gray-200 w-full h-full" />
        <button className="absolute top-4 right-4 p-2 bg-white rounded-full shadow-md">
          <HeartIcon className="w-6 h-6 text-gray-400 hover:text-red-500 transition-colors" />
        </button>
      </div>

      <div className="p-6">
        <div className="flex justify-between items-start mb-4">
          <h3 className="font-lato text-xl font-bold text-secondary">Modern Downtown Loft</h3>
          <div className="flex gap-1">
            {[...Array(5)].map((_, i) => (
              <StarIcon key={i} className="w-4 h-4 text-yellow-400 fill-yellow-400" />
            ))}
          </div>
        </div>

        <div className="flex items-center gap-2 text-gray-500 mb-6">
          <MapPinIcon className="w-5 h-5" />
          <span className="font-lato">Downtown London</span>
        </div>

        <div className="flex justify-between items-center">
          <div>
            <p className="text-2xl font-bold text-primary">$650,000</p>
            <p className="font-lato text-gray-500">1080 sqft • 4 Beds • 2 Baths</p>
          </div>
          <button className="flex items-center gap-2 bg-primary px-5 py-3 rounded-lg text-white hover:bg-primary-dark transition-colors">
            <HomeIcon className="w-5 h-5" />
            <span className="font-lato font-medium">Details</span>
          </button>
        </div>
      </div>
    </motion.div>
  );
};

export default PropertyCard;